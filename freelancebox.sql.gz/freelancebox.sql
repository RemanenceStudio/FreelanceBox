-- phpMyAdmin SQL Dump
-- version 3.3.7deb7
-- http://www.phpmyadmin.net
--
-- Serveur: localhost
-- Généré le : Jeu 22 Novembre 2012 à 10:27
-- Version du serveur: 5.1.63
-- Version de PHP: 5.3.3-7+squeeze13

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données: `freelancebox`
--

-- --------------------------------------------------------

--
-- Structure de la table `clients`
--

CREATE TABLE IF NOT EXISTS `clients` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_id` int(11) NOT NULL,
  `admin_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `contact_person` varchar(100) NOT NULL,
  `contact_email` varchar(100) NOT NULL,
  `contact_phone` varchar(30) NOT NULL,
  `address_line_1` varchar(300) NOT NULL,
  `address_line_2` varchar(300) NOT NULL,
  `code_postal` varchar(10) NOT NULL,
  `ville` varchar(255) NOT NULL,
  `security_number` varchar(50) NOT NULL,
  `additional_contacts` text NOT NULL,
  `welcome` tinyint(1) NOT NULL,
  `created` int(11) NOT NULL,
  `modified` int(11) NOT NULL,
  `logo` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Contenu de la table `clients`
--

INSERT INTO `clients` (`id`, `group_id`, `admin_id`, `name`, `contact_person`, `contact_email`, `contact_phone`, `address_line_1`, `address_line_2`, `code_postal`, `ville`, `security_number`, `additional_contacts`, `welcome`, `created`, `modified`, `logo`) VALUES
(1, 0, 0, 'Kreaweb', 'Julien SAUDAX', 'contact@kreaweb.fr', '', '32 B route de la fontainre', '', '33480', 'Moulis en mÃ©doc', '183058951205849', '', 0, 0, 0, '5041d49b9c6cb.gif'),
(2, 0, 0, 'Xavier PATERNE', 'Xavier PATERNE', 'xavier@remanence-studio.com', '0688635766', '1 Mail Pierre Mendes France', 'appt 33 RÃ©sidence Saint John s', '33600', 'Pessac', '184027511400717', '', 0, 1346160150, 1346160150, '5060195e021e5.png'),
(5, 1, 1, 'Eclypsia', 'Sebastien Danigo', 'fanzy250@gmail.com', '', '', '', '', '', '', '', 0, 1346196072, 1346196072, ''),
(6, 1, 2, 'Wanacash', 'Julien Saudax', 'jsaudax@gmail.com', '', '', '', '', '', '', '', 0, 1346226403, 1346226403, ''),
(7, 1, 2, 'Sixis', 'Sixis', 'finance@sixis.eu', '', '', '', '', '', '', '', 0, 1348473696, 1348473696, '');

-- --------------------------------------------------------

--
-- Structure de la table `files`
--

CREATE TABLE IF NOT EXISTS `files` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `client_id` int(11) NOT NULL,
  `project` int(11) NOT NULL,
  `phase` int(11) NOT NULL,
  `posted_by` int(11) NOT NULL,
  `description` varchar(150) NOT NULL,
  `file_type` varchar(20) NOT NULL,
  `size` int(11) NOT NULL,
  `path` varchar(300) NOT NULL,
  `created` int(11) NOT NULL,
  `modified` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Contenu de la table `files`
--

INSERT INTO `files` (`id`, `client_id`, `project`, `phase`, `posted_by`, `description`, `file_type`, `size`, `path`, `created`, `modified`) VALUES
(1, 6, 1, 1, 0, 'Wanacash mockup', '.jpg', 53, 'tumblr_lm4dh68Tbg1qzy9ouo1_500-1346226512.jpg', 1346226512, 1346226512);

-- --------------------------------------------------------

--
-- Structure de la table `google`
--

CREATE TABLE IF NOT EXISTS `google` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `admin_id` int(11) NOT NULL,
  `account` varchar(100) NOT NULL,
  `password` varchar(50) NOT NULL,
  `code_user` varchar(255) NOT NULL,
  `code_visibility` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Contenu de la table `google`
--

INSERT INTO `google` (`id`, `admin_id`, `account`, `password`, `code_user`, `code_visibility`) VALUES
(2, 1, 'jsaudax@gmail.com', 'tgp73p76', 'jsaudax%40gmail.com', 'private-95cf30d1b845c74f9f5ea847894cdb25'),
(4, 2, 'xavier.paterne@gmail.com', 'redalert', 'did9qgas5t0h2e8imrponlmmic%40group.calendar.google.com', 'private-cf1d5ea73f26b3af6dd9d80d87da1398');

-- --------------------------------------------------------

--
-- Structure de la table `invoices`
--

CREATE TABLE IF NOT EXISTS `invoices` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `client_id` int(11) NOT NULL,
  `admin_id` int(11) NOT NULL,
  `invoice_number` varchar(11) NOT NULL,
  `date_of_issue` int(11) NOT NULL,
  `due_date` int(11) NOT NULL,
  `total` float NOT NULL,
  `payments` float NOT NULL,
  `balance` float NOT NULL,
  `terms` text NOT NULL,
  `created` int(11) NOT NULL,
  `modified` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Contenu de la table `invoices`
--

INSERT INTO `invoices` (`id`, `client_id`, `admin_id`, `invoice_number`, `date_of_issue`, `due_date`, `total`, `payments`, `balance`, `terms`, `created`, `modified`) VALUES
(4, 7, 2, '201001', 1348437600, 1351029600, 2100, 0, 2100, 'DispensÃ© dâ€™immatriculation en application de lâ€™article L123-1-1 du code de commerce ou en \r\napplication du V de lâ€™article 19 de la loi nÂ°96-603 du 5 Juillet 1996 relative au dÃ©veloppement du \r\ncommerce et de lâ€™artisanat.', 1348473814, 1348473814),
(3, 5, 1, '201000', 1346277600, 1346277600, 0, 0, 0, '', 1346491582, 1346491582);

-- --------------------------------------------------------

--
-- Structure de la table `invoice_items`
--

CREATE TABLE IF NOT EXISTS `invoice_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `invoice_id` int(11) NOT NULL,
  `item_name` varchar(300) NOT NULL,
  `description` text NOT NULL,
  `item_quantity` int(11) NOT NULL,
  `item_rate` float NOT NULL,
  `item_type` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Contenu de la table `invoice_items`
--

INSERT INTO `invoice_items` (`id`, `invoice_id`, `item_name`, `description`, `item_quantity`, `item_rate`, `item_type`) VALUES
(2, 4, 'Prestations de design graphique', 'conception/intÃ©gration de templates web, d&#039;outils de communication/marketing\r\ndu 27/07/12 au 24/08/12', 15, 140, 'item');

-- --------------------------------------------------------

--
-- Structure de la table `messages`
--

CREATE TABLE IF NOT EXISTS `messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `admin_id` int(11) NOT NULL,
  `reference_object` varchar(20) NOT NULL,
  `reference_id` int(11) NOT NULL,
  `client_id` int(11) NOT NULL,
  `posted_by` int(11) NOT NULL,
  `message` text NOT NULL,
  `created` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Contenu de la table `messages`
--


-- --------------------------------------------------------

--
-- Structure de la table `payments`
--

CREATE TABLE IF NOT EXISTS `payments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `admin_id` int(11) NOT NULL,
  `invoice_id` int(11) NOT NULL,
  `client_id` int(11) NOT NULL,
  `amount` int(11) NOT NULL,
  `created` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Contenu de la table `payments`
--


-- --------------------------------------------------------

--
-- Structure de la table `projects`
--

CREATE TABLE IF NOT EXISTS `projects` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `admin_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `client_id` int(11) NOT NULL,
  `duration` int(11) NOT NULL,
  `phases` varchar(400) NOT NULL,
  `progress` int(11) NOT NULL,
  `created` int(11) NOT NULL,
  `modified` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Contenu de la table `projects`
--

INSERT INTO `projects` (`id`, `admin_id`, `name`, `client_id`, `duration`, `phases`, `progress`, `created`, `modified`) VALUES
(1, 2, 'Wanacash', 6, 5, 'Planning, Design, Development, Testing', 0, 1346226458, 1346226458),
(2, 2, 'Media-Circle', 7, 4, 'Design, Development', 0, 1348473748, 1348473748);

-- --------------------------------------------------------

--
-- Structure de la table `sessions`
--

CREATE TABLE IF NOT EXISTS `sessions` (
  `session_id` varchar(40) NOT NULL,
  `user_id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `ip_address` varchar(16) NOT NULL,
  `user_agent` varchar(50) NOT NULL,
  `last_activity` int(10) unsigned NOT NULL,
  PRIMARY KEY (`session_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Contenu de la table `sessions`
--

INSERT INTO `sessions` (`session_id`, `user_id`, `username`, `ip_address`, `user_agent`, `last_activity`) VALUES
('q1tm98t0em1tj4c63t4dinuh75', 1, 'contact@kreaweb.fr', '83.200.208.184', '255828c301a2b4b39adc0d3acf7051c9', 1346198399),
('p0js268sdcudukcd0eq2t7bt11', 2, 'xavier@remanence-studio.com', '212.51.179.179', 'b62142a48ed49005fd38a0d2344d0a8a', 1346228091),
('di08oj1j8db9hfgcdl7bb21570', 1, 'contact@kreaweb.fr', '212.51.179.179', '255828c301a2b4b39adc0d3acf7051c9', 1346227306),
('6jrhhv56tntsqmebpa0vpsi3q2', 1, 'contact@kreaweb.fr', '212.51.179.179', 'b62142a48ed49005fd38a0d2344d0a8a', 1346258172),
('21sancmabrc114eic9npdq5vn5', 2, 'xavier@remanence-studio.com', '82.240.38.38', 'b62142a48ed49005fd38a0d2344d0a8a', 1346274217),
('fcvnuavolqu4bv4fl16f8cjtp7', 2, 'xavier@remanence-studio.com', '212.51.179.179', 'b62142a48ed49005fd38a0d2344d0a8a', 1346313353),
('4ui3th9nt80puvt76v9fvjovt5', 1, 'contact@kreaweb.fr', '212.51.179.179', 'b62142a48ed49005fd38a0d2344d0a8a', 1346337801),
('3sai007qjf6s18ocoe5ursc7g0', 1, 'contact@kreaweb.fr', '212.51.179.179', 'b62142a48ed49005fd38a0d2344d0a8a', 1346342977),
('jhqbs2jetsji5a3sfa499vbh66', 1, 'contact@kreaweb.fr', '83.200.215.47', '255828c301a2b4b39adc0d3acf7051c9', 1346355184),
('5agpvu4cf7albvhvi9ih20m7l7', 2, 'xavier@remanence-studio.com', '82.240.38.38', 'b62142a48ed49005fd38a0d2344d0a8a', 1346355223),
('pbep2kqgtbcqe33kql9no78302', 1, 'contact@kreaweb.fr', '83.200.215.47', '255828c301a2b4b39adc0d3acf7051c9', 1346367742),
('6tsuhdiuanvn18cmcj00er7hk5', 1, 'contact@kreaweb.fr', '83.200.215.47', '52485be0df6f1da1a81726f6bbdf9a74', 1346370876),
('rnr2jkfsh9runs0rm7cui47t62', 1, 'contact@kreaweb.fr', '212.51.179.179', 'b62142a48ed49005fd38a0d2344d0a8a', 1346399096),
('8hb9t15md627b5e67vq3vahlu7', 1, 'contact@kreaweb.fr', '212.51.179.179', 'b62142a48ed49005fd38a0d2344d0a8a', 1346420953),
('n9kk50qcsh4qmqgug9crndqdp6', 2, 'xavier@remanence-studio.com', '212.51.179.179', 'b62142a48ed49005fd38a0d2344d0a8a', 1346423096),
('igp4usjtvh5g39ctoiacl5pga5', 1, 'contact@kreaweb.fr', '83.200.215.47', '52485be0df6f1da1a81726f6bbdf9a74', 1346442994),
('6376u171gppfc2na0nkv69ip11', 2, 'xavier@remanence-studio.com', '82.240.38.38', 'b62142a48ed49005fd38a0d2344d0a8a', 1346442958),
('g8j0j9rg1e1nm96bgh80s9tgr2', 1, 'contact@kreaweb.fr', '83.200.215.47', '52485be0df6f1da1a81726f6bbdf9a74', 1346491814),
('bg3sqrmvh32qkvkga51p49dsl3', 2, 'xavier@remanence-studio.com', '82.240.38.38', 'b62142a48ed49005fd38a0d2344d0a8a', 1346591162),
('mso56d9urb2jiflr3alhu5gga4', 1, 'contact@kreaweb.fr', '86.201.136.129', '52485be0df6f1da1a81726f6bbdf9a74', 1346954756),
('geoe696fm00o3b4i4thb7dhba3', 1, 'contact@kreaweb.fr', '82.125.109.6', 'f76e1da45697f2bea834d3cc529b10fb', 1347563667),
('vcefcb0d8b2h5v0sl481ip08h3', 2, 'xavier@remanence-studio.com', '212.51.179.179', '4a94daffa9075a6711b8391a3a4020d4', 1348475352),
('krat8cnj5hffc7uv6a5i14i022', 1, 'contact@kreaweb.fr', '212.51.179.179', '4a94daffa9075a6711b8391a3a4020d4', 1348558909),
('hqon5428b2dm4bmk1tlvqgmq73', 2, 'xavier@remanence-studio.com', '82.240.38.38', 'b62142a48ed49005fd38a0d2344d0a8a', 1349220544),
('9gqud4foannj5i45pq0hr0jgq2', 2, 'xavier@remanence-studio.com', '212.51.179.179', 'd2e6e1f365d3dc697b1675d5eb83ee63', 1351064745),
('b4od1kcfbvvu81lt5afeipc261', 1, 'contact@kreaweb.fr', '212.51.179.179', 'd2e6e1f365d3dc697b1675d5eb83ee63', 1351072942),
('cktpcg4vencvb47duo80iu7nm2', 2, 'xavier@remanence-studio.com', '212.51.179.179', 'd2e6e1f365d3dc697b1675d5eb83ee63', 1351068984),
('f14no08996tkepi86e09a5d8v7', 2, 'xavier@remanence-studio.com', '212.51.179.179', 'd2e6e1f365d3dc697b1675d5eb83ee63', 1351073077),
('vtt67v0gaeaage3oof065l8ki7', 1, 'contact@kreaweb.fr', '212.51.179.179', 'd2e6e1f365d3dc697b1675d5eb83ee63', 1351079359),
('plkvuqqrglvlo1i47vq9so94a5', 2, 'xavier@remanence-studio.com', '212.51.179.179', 'a2b88e6f5ea8449210b73229691e53be', 1353494668),
('4qicaeqqednvr7cur86ms2p1g4', 2, 'xavier@remanence-studio.com', '212.51.179.179', 'cb9d57facf28518d7f7f3f9167c86dea', 1353574618);

-- --------------------------------------------------------

--
-- Structure de la table `timesheets`
--

CREATE TABLE IF NOT EXISTS `timesheets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `admin_id` int(11) NOT NULL,
  `account_id` int(11) NOT NULL,
  `file` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=27 ;

--
-- Contenu de la table `timesheets`
--

INSERT INTO `timesheets` (`id`, `admin_id`, `account_id`, `file`) VALUES
(12, 2, 4, 'timesheet24-09-2012-103012'),
(15, 1, 2, 'timesheet25-09-2012-094843'),
(18, 2, 4, 'timesheet24-10-2012-094958'),
(26, 1, 2, 'timesheet24-10-2012-135103');

-- --------------------------------------------------------

--
-- Structure de la table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `client_id` int(11) NOT NULL,
  `password` varchar(255) NOT NULL,
  `salt` varchar(255) NOT NULL,
  `tmp_pass` varchar(6) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Contenu de la table `users`
--

INSERT INTO `users` (`id`, `client_id`, `password`, `salt`, `tmp_pass`) VALUES
(1, 1, '052acd52b567dc0b13a59a655028bc9a66cd68bf98fdd39c29af4693a2ff0fe6', 'e105c50ecd59a03a036658e125aee653301063e801c02dbd1ca2bd4363e5bc8e', ''),
(2, 2, 'd364f981215ac19b94ddd4be3be51084df7d036456217cf84f6d3740ab715e51', '72e396c635e6ee392e7e33f25245da52cc433e7336f6e23ee85f312a8546f586', ''),
(6, 6, '5964b119ae737721c6f8a89ac79fdceae2653aa782950fe8a53bac7a2bcd5d88', 'e2be738b77725055d9c0d8b2506f6d6f2f0c793477770daea25d03d353d09038', '352bfe'),
(5, 5, '09a718767d900cd7aa23612546abfd8c9144d2d8a9754f45a3cfd3a8c8b2a8b5', '725b3a4751aab65b724c2336d8c7f08504615d4d884c06dfd6f6dc8afb3f6b77', '823d36'),
(7, 7, '37288254cab1700b674bf5aac58c2c389588d299a83ff2837751bfda89e59921', '017ae95ebad60c1a07547c991b423b1f812646f71feb480a0b0bba9c400329cc', '0dfc57');
